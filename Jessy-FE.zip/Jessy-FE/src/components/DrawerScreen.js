import React from "react";
import {Text, View} from "react-native";

const DrawerScreen = () => {
  return (
    <View>
      <Text>The Notifications panel</Text>
    </View>
  );
};

export default DrawerScreen;
