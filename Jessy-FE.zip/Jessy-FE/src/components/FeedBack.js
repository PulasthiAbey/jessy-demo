import React from "react";
import {Text, View} from "react-native";

const FeedBack = () => {
  return (
    <View>
      <Text>Feedback Screen</Text>
    </View>
  );
};

export default FeedBack;
