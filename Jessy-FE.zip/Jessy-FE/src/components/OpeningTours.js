import React from "react";
import {Text} from "react-native";
import {View} from "react-native-animatable";

const OpeningTours = () => {
  return (
    <View>
      <Text>Onging tours</Text>
    </View>
  );
};

export default OpeningTours;
