import React from "react";
import {Text, View} from "react-native";

const CompletedTours = () => {
  return (
    <View>
      <Text>Completed Tours</Text>
    </View>
  );
};

export default CompletedTours;
